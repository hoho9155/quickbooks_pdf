It would be better to work on sk ype.
live:.cid.350c141d28ed3850
I can help you continuously on it.